<?php

namespace WebArchers\PDFInvoice\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use WebArchers\PDFInvoice\Model\PdfinvoiceFactory;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\Result\RedirectFactory;

class Login extends Action
{
    protected $_pageFactory;
    protected $pdfinvoiceFactory;
    protected $resultRedirectFactory;
    public function __construct(
         Context $context,
         PdfinvoiceFactory $pdfinvoiceFactory,
         PageFactory $pageFactory,
         RedirectFactory $resultRedirectFactory
         
         )
        {
            $this->_pageFactory = $pageFactory;
            $this->pdfinvoiceFactory = $pdfinvoiceFactory;
            $this->resultRedirectFactory = $resultRedirectFactory;
            
            return parent::__construct($context);
        }
        public function execute()
        {
            
                    $params = $this->getRequest()->getParams();
                    //var_dump($params);

                // Retrieve the email and password values from the request parameters
                $email = isset($params['email_id']) ? $params['email_id'] : '';
                //var_dump($email);
                $password = isset($params['password']) ? $params['password'] : '';
                //var_dump($password);

                // Load the model by email
                $model = $this->pdfinvoiceFactory->create();
                $model->load($email, 'email_id');
                if ($model->getId() && $model->getPassword() === $password) {
                    var_dump($model->getId());
                    var_dump($model->getPassword());
                    var_dump($password);
                    $redirect = $this->resultRedirectFactory->create();
                    $redirect->setPath('pdfinvoice/index/showdata');
                    return $redirect;    

                } else {
                    // Login failed, display an error message
                    $this->messageManager->addErrorMessage(__('Invalid email or password.'));
                    $redirect = $this->resultRedirectFactory->create();
                    $redirect->setPath('pdfinvoice/index/login/');
                    return $redirect;
                }
            
            
            return $this->_pageFactory->create();
        }

}

